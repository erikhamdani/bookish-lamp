
import requests, pandas as pd, json

def get_dummy_data():
    return pd.DataFrame([
      {"code":"BBCA","name":"Bank Central Asia","net_income":450e9,"per":15.2,"pbv":3.4},
      {"code":"TLKM","name":"Telkom Indonesia","net_income":250e9,"per":13.1,"pbv":2.1},
      {"code":"ASII","name":"Astra Intl","net_income":180e9,"per":9.8,"pbv":1.7},
      {"code":"INDY","name":"Indika Energy","net_income":120e9,"per":6.5,"pbv":0.9},
    ])

if __name__=="__main__":
    df = get_dummy_data()
    df.to_json("idx_stocks.json", orient="records", indent=2)
